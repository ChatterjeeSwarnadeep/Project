package com.App.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.App.model.Student;
import com.App.repo.Repository;

@RestController
public class WebController {
@Autowired
Repository rep;
@RequestMapping(value="/stu",method=RequestMethod.POST)
public String add(@RequestBody Student s) {
	rep.save(s);
	return "Done";
}
@RequestMapping("/stu")
public String getall()
{
	String res="<html>";
	for(Student s:rep.findAll())
	{
		res+="<div>"+s.toString()+"/<div>";
	}
	return res+"<html>";
}
@RequestMapping(value="/stu/{id}",method=RequestMethod.PUT)
public String update(@PathVariable("id")String id,@RequestBody Student s)
{
	rep.save(s);
	return "D0ne";
}
@RequestMapping(value="/stu/{id}",method=RequestMethod.DELETE)
public String del(@PathVariable("id")String id)
{
	rep.delete(id);
	return "Deleted";
}

@RequestMapping("/stubyid")
public String find1(@RequestParam("id")String roll )
{
	String res="<html>";
	res+=rep.findOne(roll).toString();	
	return res+"</html>";
}
}
