package com.App.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student")
public class Student implements Serializable {
/**
	 * 
	 */
	private static final long serialVersionUID = 1436155372485747074L;
@Id
@Column(name="roll")
private String roll;
@Column(name="name")
private String name;
@Column(name="age")
private String age;
protected Student() {
}
public Student(String roll, String name, String age) {
	this.roll = roll;
	this.name = name;
	this.age = age;
}
public String getRoll() {
	return roll;
}
public void setRoll(String roll) {
	this.roll = roll;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
@Override
public String toString() {
	return String.format("Student[id='%s', Name='%s', Age='%s']", roll, name, age);
}
}
