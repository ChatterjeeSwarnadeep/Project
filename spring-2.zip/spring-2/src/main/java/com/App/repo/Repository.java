package com.App.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.App.model.Student;
public interface Repository extends CrudRepository<Student, String>{
	
}
