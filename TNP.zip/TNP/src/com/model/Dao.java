package com.model;

import java.sql.*;
import java.util.LinkedList;

import com.db.*;
public class Dao {
	public static LinkedList<Db> login(Db d) throws Exception
	{
		int status=0;
		LinkedList<Db>list=new LinkedList<Db>();
		Connection con=Provider.getConnection();
		PreparedStatement pst=con.prepareStatement("select * from login where type=? and roll=? and pass=?");
		pst.setString(1, d.getType());
		pst.setString(2, d.getRoll());
		pst.setString(3, d.getPass());
		ResultSet rs=pst.executeQuery();
		if(rs.next()){
			Db us1=new Db();
		us1.setType(rs.getString("type"));
		us1.setRoll(rs.getString("roll"));
		us1.setPass(rs.getString("pass"));
		list.add(us1);
			}
		else
			list=null;
		return list;
		
	}
	public static LinkedList<User> notice()throws Exception
	{

		ResultSet rs=null;
		int status = 0;
		Connection con=Provider.getConnection();
		LinkedList<User>list=new LinkedList<User>();
		PreparedStatement pst=con.prepareStatement("select * from new");
		rs=pst.executeQuery();
		while(rs.next())
		{
			User us=new User();
			us.setCap(rs.getString("caption"));
			us.setDes(rs.getString("name"));
			us.setUrl(rs.getString("url"));
			us.setDate(rs.getDate("sub"));
			list.add(us);
		}
		return list;
	}
	public static int chng (Db u)throws Exception
	{
		int status=0;
		Connection con=Provider.getConnection();
		PreparedStatement pst=con.prepareStatement("UPDATE login set pass=? where roll=?");
		pst.setString(1, u.getPass());
		pst.setString(2, u.getRoll());
		status=pst.executeUpdate();
		return status;
		}
}