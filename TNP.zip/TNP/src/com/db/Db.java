package com.db;

public class Db {
private String roll;
private String pass;
private String type;
public String getRoll() {
	return roll;
}
public void setRoll(String roll) {
	this.roll = roll;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}

}
