package com.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class Provider {
	static Connection con=null;	
	public static Connection getConnection() throws Exception {
		if(con==null)
		{
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/newDb","root","swarnadeep");
		}
		return con;
	}

}