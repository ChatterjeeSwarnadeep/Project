package com.db;

import java.util.Date;
public class User {
private String des;
private String url;
private Date date;
private String cap;
public String getDes() {
	return des;
}
public void setDes(String des) {
	this.des = des;
}
public String getUrl() {
	return url;
}
public void setUrl(String url) {
	this.url = url;
}
public Date getDate() {
	return date;
}
public void setDate(Date date2) {
	this.date = date2;
}
public String getCap() {
	return cap;
}
public void setCap(String cap) {
	this.cap = cap;
}

}
